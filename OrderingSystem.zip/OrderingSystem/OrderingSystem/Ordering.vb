﻿Public Class Ordering
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnShowParts.Click
        'Path might change depending on where the program is located
        System.Diagnostics.Process.Start("C:\Users\rodri\OneDrive\Documents\visual studio 2015\Projects\OrderingSystem\OrderingSystem\parts.csv")
    End Sub
End Class
