﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ordering
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblVehicle = New System.Windows.Forms.Label()
        Me.btnShowParts = New System.Windows.Forms.Button()
        Me.cbVehicles = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'lblVehicle
        '
        Me.lblVehicle.AutoSize = True
        Me.lblVehicle.Location = New System.Drawing.Point(46, 62)
        Me.lblVehicle.Name = "lblVehicle"
        Me.lblVehicle.Size = New System.Drawing.Size(45, 13)
        Me.lblVehicle.TabIndex = 0
        Me.lblVehicle.Text = "Vehicle:"
        '
        'btnShowParts
        '
        Me.btnShowParts.Location = New System.Drawing.Point(97, 150)
        Me.btnShowParts.Name = "btnShowParts"
        Me.btnShowParts.Size = New System.Drawing.Size(92, 30)
        Me.btnShowParts.TabIndex = 1
        Me.btnShowParts.Text = "Show Parts"
        Me.btnShowParts.UseVisualStyleBackColor = True
        '
        'cbVehicles
        '
        Me.cbVehicles.FormattingEnabled = True
        Me.cbVehicles.Items.AddRange(New Object() {"1", "2", "3", "4"})
        Me.cbVehicles.Location = New System.Drawing.Point(97, 59)
        Me.cbVehicles.Name = "cbVehicles"
        Me.cbVehicles.Size = New System.Drawing.Size(121, 21)
        Me.cbVehicles.TabIndex = 2
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.cbVehicles)
        Me.Controls.Add(Me.btnShowParts)
        Me.Controls.Add(Me.lblVehicle)
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.Text = "Ordering"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblVehicle As Label
    Friend WithEvents btnShowParts As Button
    Friend WithEvents cbVehicles As ComboBox
End Class
