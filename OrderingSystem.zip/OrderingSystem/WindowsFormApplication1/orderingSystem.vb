﻿Public Class orderingSystem
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Path might change depending on where the program is located
        System.Diagnostics.Process.Start("C:\Users\rodri\OneDrive\Documents\visual studio 2015\Projects\WindowsApplication1\WindowsApplication1\parts.csv")
    End Sub

End Class
