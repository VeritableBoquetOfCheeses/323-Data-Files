﻿Option Strict On
Public Class PayrollForm

    Dim gStartDate As String
    Dim gEndDate As String
    Dim gPayPath As String
    Dim gInputPath As String
    Dim gTaxPath As String
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        gPayPath = "C:\Users\scottwh\Desktop\Biweekly_Payroll_11-16_thru_11-29.txt"
        gInputPath = "C:\Users\scottwh\Desktop\biweeklyCheese.csv"
        gTaxPath = "C:\Users\scottwh\Desktop\2017TaxInfo.txt"
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim result As String
        result = String.Format("{0,-20}{1,-20}{2,-20}{3,-20}{4,-20}{5,-20}", "First", "Last", "SSN", "Pay Rate", "Hours", "Gross Pay")
        My.Computer.FileSystem.WriteAllText(gPayPath, "Payroll for dates:  " & gStartDate & " - " & gEndDate & vbCrLf, True)
        My.Computer.FileSystem.WriteAllText(gPayPath, vbCrLf & result & vbCrLf & vbCrLf, True)

        Using MyReader As New Microsoft.VisualBasic.
            FileIO.TextFieldParser(gInputPath)
            MyReader.TextFieldType = FileIO.FieldType.Delimited
            MyReader.SetDelimiters(",")
            Dim currentRow As String()
            While Not MyReader.EndOfData
                Try
                    currentRow = MyReader.ReadFields()
                    Dim currentField As String
                    For Each currentField In currentRow
                        currentField = String.Format("{0,-20}", currentField)
                        My.Computer.FileSystem.WriteAllText(gPayPath, currentField, True)
                    Next
                    My.Computer.FileSystem.WriteAllText(gPayPath, vbCrLf, True)
                Catch ex As Microsoft.VisualBasic.
                    FileIO.MalformedLineException
                    MsgBox("Line " & ex.Message & "is not valid and will be skipped.")
                End Try
            End While
        End Using

        System.Diagnostics.Process.Start(gPayPath)
    End Sub

    Private Sub dtpStartDate_DateChanged(sender As Object, e As DateRangeEventArgs) Handles dtpStartDate.DateChanged
        dtpStartDate.MaxSelectionCount = 14
        gStartDate = dtpStartDate.SelectionRange.Start.ToString()
        gEndDate = dtpStartDate.SelectionRange.End.ToString()
    End Sub

    Private Sub btnTaxInfo_Click(sender As Object, e As EventArgs) Handles btnTaxInfo.Click
        System.Diagnostics.Process.Start(gTaxPath)
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
