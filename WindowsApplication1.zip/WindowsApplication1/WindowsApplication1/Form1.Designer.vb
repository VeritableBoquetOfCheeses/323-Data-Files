﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtCustomerName = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtCarYear = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtMake = New System.Windows.Forms.TextBox()
        Me.txtModel = New System.Windows.Forms.TextBox()
        Me.City = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtZIPCode = New System.Windows.Forms.TextBox()
        Me.txtProblem = New System.Windows.Forms.RichTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.txtSubTotal5 = New System.Windows.Forms.TextBox()
        Me.txtQuantity5 = New System.Windows.Forms.TextBox()
        Me.txtUnitPrice5 = New System.Windows.Forms.TextBox()
        Me.txtPartName5 = New System.Windows.Forms.TextBox()
        Me.txtSubTotal4 = New System.Windows.Forms.TextBox()
        Me.txtQuantity4 = New System.Windows.Forms.TextBox()
        Me.txtUnitPrice4 = New System.Windows.Forms.TextBox()
        Me.txtPartName4 = New System.Windows.Forms.TextBox()
        Me.txtSubTotal3 = New System.Windows.Forms.TextBox()
        Me.txtQuantity3 = New System.Windows.Forms.TextBox()
        Me.txtUnitPrice3 = New System.Windows.Forms.TextBox()
        Me.txtPartName3 = New System.Windows.Forms.TextBox()
        Me.txtSubTotal2 = New System.Windows.Forms.TextBox()
        Me.txtQuantity2 = New System.Windows.Forms.TextBox()
        Me.txtUnitPrice2 = New System.Windows.Forms.TextBox()
        Me.txtPartName2 = New System.Windows.Forms.TextBox()
        Me.txtSubTotal1 = New System.Windows.Forms.TextBox()
        Me.txtQuantity1 = New System.Windows.Forms.TextBox()
        Me.txtUnitPrice1 = New System.Windows.Forms.TextBox()
        Me.txtPartName1 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtJobPrice5 = New System.Windows.Forms.TextBox()
        Me.txtJobPrice4 = New System.Windows.Forms.TextBox()
        Me.txtJobPerformed5 = New System.Windows.Forms.TextBox()
        Me.txtJobPerformed4 = New System.Windows.Forms.TextBox()
        Me.txtJobPrice2 = New System.Windows.Forms.TextBox()
        Me.txtJobPrice3 = New System.Windows.Forms.TextBox()
        Me.txtJobPerformed3 = New System.Windows.Forms.TextBox()
        Me.txtJobPerformed2 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtJobPrice1 = New System.Windows.Forms.TextBox()
        Me.txtJobPerformed1 = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MnuFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileNew = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileOpen = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileSave = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFilePrint = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.txtTotalOrder = New System.Windows.Forms.TextBox()
        Me.txtTaxAmount = New System.Windows.Forms.TextBox()
        Me.txtTaxRate = New System.Windows.Forms.TextBox()
        Me.txtTotalLabor = New System.Windows.Forms.TextBox()
        Me.txtTotalParts = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.dlgPrint = New System.Windows.Forms.PrintDialog()
        Me.docPrint = New System.Drawing.Printing.PrintDocument()
        Me.btnShowFile = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 68)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Customer Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(20, 176)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(68, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Make/Model"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 215)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(29, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Year"
        '
        'txtCustomerName
        '
        Me.txtCustomerName.Location = New System.Drawing.Point(94, 65)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.Size = New System.Drawing.Size(100, 20)
        Me.txtCustomerName.TabIndex = 5
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(94, 100)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(100, 20)
        Me.txtAddress.TabIndex = 6
        '
        'txtCarYear
        '
        Me.txtCarYear.Location = New System.Drawing.Point(94, 215)
        Me.txtCarYear.Name = "txtCarYear"
        Me.txtCarYear.Size = New System.Drawing.Size(100, 20)
        Me.txtCarYear.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(20, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Order Date"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(87, 26)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 9
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(29, 107)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 13)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Address"
        '
        'txtMake
        '
        Me.txtMake.Location = New System.Drawing.Point(94, 176)
        Me.txtMake.Name = "txtMake"
        Me.txtMake.Size = New System.Drawing.Size(100, 20)
        Me.txtMake.TabIndex = 11
        '
        'txtModel
        '
        Me.txtModel.Location = New System.Drawing.Point(210, 176)
        Me.txtModel.Name = "txtModel"
        Me.txtModel.Size = New System.Drawing.Size(100, 20)
        Me.txtModel.TabIndex = 12
        '
        'City
        '
        Me.City.AutoSize = True
        Me.City.Location = New System.Drawing.Point(29, 140)
        Me.City.Name = "City"
        Me.City.Size = New System.Drawing.Size(24, 13)
        Me.City.TabIndex = 13
        Me.City.Text = "City"
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(94, 137)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(100, 20)
        Me.txtCity.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(221, 140)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "State"
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(272, 137)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(100, 20)
        Me.txtState.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(388, 140)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(22, 13)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Zip"
        '
        'txtZIPCode
        '
        Me.txtZIPCode.Location = New System.Drawing.Point(427, 133)
        Me.txtZIPCode.Name = "txtZIPCode"
        Me.txtZIPCode.Size = New System.Drawing.Size(100, 20)
        Me.txtZIPCode.TabIndex = 18
        '
        'txtProblem
        '
        Me.txtProblem.Location = New System.Drawing.Point(73, 241)
        Me.txtProblem.Name = "txtProblem"
        Me.txtProblem.Size = New System.Drawing.Size(360, 74)
        Me.txtProblem.TabIndex = 19
        Me.txtProblem.Text = ""
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(10, 274)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(60, 13)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Description"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DateTimePicker1)
        Me.GroupBox1.Controls.Add(Me.txtZIPCode)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.txtState)
        Me.GroupBox1.Controls.Add(Me.txtProblem)
        Me.GroupBox1.Controls.Add(Me.txtCustomerName)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtAddress)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.City)
        Me.GroupBox1.Controls.Add(Me.txtCarYear)
        Me.GroupBox1.Controls.Add(Me.txtModel)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtCity)
        Me.GroupBox1.Controls.Add(Me.txtMake)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(2, 23)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(532, 329)
        Me.GroupBox1.TabIndex = 21
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Customer and Car Information"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtSubTotal5)
        Me.GroupBox2.Controls.Add(Me.txtQuantity5)
        Me.GroupBox2.Controls.Add(Me.txtUnitPrice5)
        Me.GroupBox2.Controls.Add(Me.txtPartName5)
        Me.GroupBox2.Controls.Add(Me.txtSubTotal4)
        Me.GroupBox2.Controls.Add(Me.txtQuantity4)
        Me.GroupBox2.Controls.Add(Me.txtUnitPrice4)
        Me.GroupBox2.Controls.Add(Me.txtPartName4)
        Me.GroupBox2.Controls.Add(Me.txtSubTotal3)
        Me.GroupBox2.Controls.Add(Me.txtQuantity3)
        Me.GroupBox2.Controls.Add(Me.txtUnitPrice3)
        Me.GroupBox2.Controls.Add(Me.txtPartName3)
        Me.GroupBox2.Controls.Add(Me.txtSubTotal2)
        Me.GroupBox2.Controls.Add(Me.txtQuantity2)
        Me.GroupBox2.Controls.Add(Me.txtUnitPrice2)
        Me.GroupBox2.Controls.Add(Me.txtPartName2)
        Me.GroupBox2.Controls.Add(Me.txtSubTotal1)
        Me.GroupBox2.Controls.Add(Me.txtQuantity1)
        Me.GroupBox2.Controls.Add(Me.txtUnitPrice1)
        Me.GroupBox2.Controls.Add(Me.txtPartName1)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Location = New System.Drawing.Point(2, 358)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(532, 169)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Parts Used"
        '
        'txtSubTotal5
        '
        Me.txtSubTotal5.Location = New System.Drawing.Point(427, 143)
        Me.txtSubTotal5.Name = "txtSubTotal5"
        Me.txtSubTotal5.Size = New System.Drawing.Size(71, 20)
        Me.txtSubTotal5.TabIndex = 23
        Me.txtSubTotal5.Text = "0.00"
        '
        'txtQuantity5
        '
        Me.txtQuantity5.Location = New System.Drawing.Point(340, 141)
        Me.txtQuantity5.Name = "txtQuantity5"
        Me.txtQuantity5.Size = New System.Drawing.Size(32, 20)
        Me.txtQuantity5.TabIndex = 22
        Me.txtQuantity5.Text = "0"
        '
        'txtUnitPrice5
        '
        Me.txtUnitPrice5.Location = New System.Drawing.Point(259, 141)
        Me.txtUnitPrice5.Name = "txtUnitPrice5"
        Me.txtUnitPrice5.Size = New System.Drawing.Size(67, 20)
        Me.txtUnitPrice5.TabIndex = 21
        Me.txtUnitPrice5.Text = "0.00"
        '
        'txtPartName5
        '
        Me.txtPartName5.Location = New System.Drawing.Point(6, 141)
        Me.txtPartName5.Name = "txtPartName5"
        Me.txtPartName5.Size = New System.Drawing.Size(243, 20)
        Me.txtPartName5.TabIndex = 20
        '
        'txtSubTotal4
        '
        Me.txtSubTotal4.Location = New System.Drawing.Point(427, 115)
        Me.txtSubTotal4.Name = "txtSubTotal4"
        Me.txtSubTotal4.Size = New System.Drawing.Size(71, 20)
        Me.txtSubTotal4.TabIndex = 19
        Me.txtSubTotal4.Text = "0.00"
        '
        'txtQuantity4
        '
        Me.txtQuantity4.Location = New System.Drawing.Point(340, 115)
        Me.txtQuantity4.Name = "txtQuantity4"
        Me.txtQuantity4.Size = New System.Drawing.Size(32, 20)
        Me.txtQuantity4.TabIndex = 18
        Me.txtQuantity4.Text = "0"
        '
        'txtUnitPrice4
        '
        Me.txtUnitPrice4.Location = New System.Drawing.Point(259, 115)
        Me.txtUnitPrice4.Name = "txtUnitPrice4"
        Me.txtUnitPrice4.Size = New System.Drawing.Size(67, 20)
        Me.txtUnitPrice4.TabIndex = 17
        Me.txtUnitPrice4.Text = "0.00"
        '
        'txtPartName4
        '
        Me.txtPartName4.Location = New System.Drawing.Point(10, 115)
        Me.txtPartName4.Name = "txtPartName4"
        Me.txtPartName4.Size = New System.Drawing.Size(243, 20)
        Me.txtPartName4.TabIndex = 16
        '
        'txtSubTotal3
        '
        Me.txtSubTotal3.Location = New System.Drawing.Point(427, 89)
        Me.txtSubTotal3.Name = "txtSubTotal3"
        Me.txtSubTotal3.Size = New System.Drawing.Size(71, 20)
        Me.txtSubTotal3.TabIndex = 15
        Me.txtSubTotal3.Text = "0.00"
        '
        'txtQuantity3
        '
        Me.txtQuantity3.Location = New System.Drawing.Point(340, 89)
        Me.txtQuantity3.Name = "txtQuantity3"
        Me.txtQuantity3.Size = New System.Drawing.Size(32, 20)
        Me.txtQuantity3.TabIndex = 14
        Me.txtQuantity3.Text = "0"
        '
        'txtUnitPrice3
        '
        Me.txtUnitPrice3.Location = New System.Drawing.Point(259, 89)
        Me.txtUnitPrice3.Name = "txtUnitPrice3"
        Me.txtUnitPrice3.Size = New System.Drawing.Size(67, 20)
        Me.txtUnitPrice3.TabIndex = 13
        Me.txtUnitPrice3.Text = "0.00"
        '
        'txtPartName3
        '
        Me.txtPartName3.Location = New System.Drawing.Point(10, 89)
        Me.txtPartName3.Name = "txtPartName3"
        Me.txtPartName3.Size = New System.Drawing.Size(243, 20)
        Me.txtPartName3.TabIndex = 12
        '
        'txtSubTotal2
        '
        Me.txtSubTotal2.Location = New System.Drawing.Point(427, 63)
        Me.txtSubTotal2.Name = "txtSubTotal2"
        Me.txtSubTotal2.Size = New System.Drawing.Size(71, 20)
        Me.txtSubTotal2.TabIndex = 11
        Me.txtSubTotal2.Text = "0.00"
        '
        'txtQuantity2
        '
        Me.txtQuantity2.Location = New System.Drawing.Point(340, 63)
        Me.txtQuantity2.Name = "txtQuantity2"
        Me.txtQuantity2.Size = New System.Drawing.Size(32, 20)
        Me.txtQuantity2.TabIndex = 10
        Me.txtQuantity2.Text = "0"
        '
        'txtUnitPrice2
        '
        Me.txtUnitPrice2.Location = New System.Drawing.Point(259, 63)
        Me.txtUnitPrice2.Name = "txtUnitPrice2"
        Me.txtUnitPrice2.Size = New System.Drawing.Size(67, 20)
        Me.txtUnitPrice2.TabIndex = 9
        Me.txtUnitPrice2.Text = "0.00"
        '
        'txtPartName2
        '
        Me.txtPartName2.Location = New System.Drawing.Point(10, 63)
        Me.txtPartName2.Name = "txtPartName2"
        Me.txtPartName2.Size = New System.Drawing.Size(243, 20)
        Me.txtPartName2.TabIndex = 8
        '
        'txtSubTotal1
        '
        Me.txtSubTotal1.Location = New System.Drawing.Point(427, 37)
        Me.txtSubTotal1.Name = "txtSubTotal1"
        Me.txtSubTotal1.Size = New System.Drawing.Size(71, 20)
        Me.txtSubTotal1.TabIndex = 7
        Me.txtSubTotal1.Text = "0.00"
        '
        'txtQuantity1
        '
        Me.txtQuantity1.Location = New System.Drawing.Point(340, 37)
        Me.txtQuantity1.Name = "txtQuantity1"
        Me.txtQuantity1.Size = New System.Drawing.Size(32, 20)
        Me.txtQuantity1.TabIndex = 6
        Me.txtQuantity1.Text = "0"
        '
        'txtUnitPrice1
        '
        Me.txtUnitPrice1.Location = New System.Drawing.Point(259, 37)
        Me.txtUnitPrice1.Name = "txtUnitPrice1"
        Me.txtUnitPrice1.Size = New System.Drawing.Size(67, 20)
        Me.txtUnitPrice1.TabIndex = 5
        Me.txtUnitPrice1.Text = "0.00"
        '
        'txtPartName1
        '
        Me.txtPartName1.Location = New System.Drawing.Point(10, 37)
        Me.txtPartName1.Name = "txtPartName1"
        Me.txtPartName1.Size = New System.Drawing.Size(243, 20)
        Me.txtPartName1.TabIndex = 4
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(427, 18)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(53, 13)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Sub Total"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(337, 19)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(46, 13)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Quantity"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(264, 19)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(53, 13)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Unit Price"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(7, 20)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Part Name:"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtJobPrice5)
        Me.GroupBox3.Controls.Add(Me.txtJobPrice4)
        Me.GroupBox3.Controls.Add(Me.txtJobPerformed5)
        Me.GroupBox3.Controls.Add(Me.txtJobPerformed4)
        Me.GroupBox3.Controls.Add(Me.txtJobPrice2)
        Me.GroupBox3.Controls.Add(Me.txtJobPrice3)
        Me.GroupBox3.Controls.Add(Me.txtJobPerformed3)
        Me.GroupBox3.Controls.Add(Me.txtJobPerformed2)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.txtJobPrice1)
        Me.GroupBox3.Controls.Add(Me.txtJobPerformed1)
        Me.GroupBox3.Location = New System.Drawing.Point(2, 533)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(532, 148)
        Me.GroupBox3.TabIndex = 23
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Jobs Performed"
        '
        'txtJobPrice5
        '
        Me.txtJobPrice5.Location = New System.Drawing.Point(391, 128)
        Me.txtJobPrice5.Name = "txtJobPrice5"
        Me.txtJobPrice5.Size = New System.Drawing.Size(100, 20)
        Me.txtJobPrice5.TabIndex = 10
        Me.txtJobPrice5.Text = "0.00"
        '
        'txtJobPrice4
        '
        Me.txtJobPrice4.Location = New System.Drawing.Point(391, 100)
        Me.txtJobPrice4.Name = "txtJobPrice4"
        Me.txtJobPrice4.Size = New System.Drawing.Size(100, 20)
        Me.txtJobPrice4.TabIndex = 9
        Me.txtJobPrice4.Text = "0.00"
        '
        'txtJobPerformed5
        '
        Me.txtJobPerformed5.Location = New System.Drawing.Point(9, 126)
        Me.txtJobPerformed5.Name = "txtJobPerformed5"
        Me.txtJobPerformed5.Size = New System.Drawing.Size(319, 20)
        Me.txtJobPerformed5.TabIndex = 8
        '
        'txtJobPerformed4
        '
        Me.txtJobPerformed4.Location = New System.Drawing.Point(10, 100)
        Me.txtJobPerformed4.Name = "txtJobPerformed4"
        Me.txtJobPerformed4.Size = New System.Drawing.Size(319, 20)
        Me.txtJobPerformed4.TabIndex = 7
        '
        'txtJobPrice2
        '
        Me.txtJobPrice2.Location = New System.Drawing.Point(391, 48)
        Me.txtJobPrice2.Name = "txtJobPrice2"
        Me.txtJobPrice2.Size = New System.Drawing.Size(100, 20)
        Me.txtJobPrice2.TabIndex = 6
        Me.txtJobPrice2.Text = "0.00"
        '
        'txtJobPrice3
        '
        Me.txtJobPrice3.Location = New System.Drawing.Point(391, 74)
        Me.txtJobPrice3.Name = "txtJobPrice3"
        Me.txtJobPrice3.Size = New System.Drawing.Size(100, 20)
        Me.txtJobPrice3.TabIndex = 5
        Me.txtJobPrice3.Text = "0.00"
        '
        'txtJobPerformed3
        '
        Me.txtJobPerformed3.Location = New System.Drawing.Point(9, 74)
        Me.txtJobPerformed3.Name = "txtJobPerformed3"
        Me.txtJobPerformed3.Size = New System.Drawing.Size(319, 20)
        Me.txtJobPerformed3.TabIndex = 4
        '
        'txtJobPerformed2
        '
        Me.txtJobPerformed2.Location = New System.Drawing.Point(10, 48)
        Me.txtJobPerformed2.Name = "txtJobPerformed2"
        Me.txtJobPerformed2.Size = New System.Drawing.Size(319, 20)
        Me.txtJobPerformed2.TabIndex = 3
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(430, 11)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(31, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "Price"
        '
        'txtJobPrice1
        '
        Me.txtJobPrice1.Location = New System.Drawing.Point(391, 22)
        Me.txtJobPrice1.Name = "txtJobPrice1"
        Me.txtJobPrice1.Size = New System.Drawing.Size(100, 20)
        Me.txtJobPrice1.TabIndex = 1
        Me.txtJobPrice1.Text = "0.00"
        '
        'txtJobPerformed1
        '
        Me.txtJobPerformed1.Location = New System.Drawing.Point(10, 22)
        Me.txtJobPerformed1.Name = "txtJobPerformed1"
        Me.txtJobPerformed1.Size = New System.Drawing.Size(319, 20)
        Me.txtJobPerformed1.TabIndex = 0
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(764, 24)
        Me.MenuStrip1.TabIndex = 24
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MnuFileToolStripMenuItem, Me.mnuFileExit})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(37, 20)
        Me.ToolStripMenuItem1.Text = "&File"
        '
        'MnuFileToolStripMenuItem
        '
        Me.MnuFileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileNew, Me.mnuFileOpen, Me.mnuFileSave, Me.mnuFilePrint})
        Me.MnuFileToolStripMenuItem.Name = "MnuFileToolStripMenuItem"
        Me.MnuFileToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.MnuFileToolStripMenuItem.Text = "mnuFile"
        '
        'mnuFileNew
        '
        Me.mnuFileNew.Name = "mnuFileNew"
        Me.mnuFileNew.Size = New System.Drawing.Size(179, 22)
        Me.mnuFileNew.Text = "&New Repair Order"
        '
        'mnuFileOpen
        '
        Me.mnuFileOpen.Name = "mnuFileOpen"
        Me.mnuFileOpen.Size = New System.Drawing.Size(179, 22)
        Me.mnuFileOpen.Text = "&Open Existing Order"
        '
        'mnuFileSave
        '
        Me.mnuFileSave.Name = "mnuFileSave"
        Me.mnuFileSave.Size = New System.Drawing.Size(179, 22)
        Me.mnuFileSave.Text = "&Save Current Order"
        '
        'mnuFilePrint
        '
        Me.mnuFilePrint.Name = "mnuFilePrint"
        Me.mnuFilePrint.Size = New System.Drawing.Size(179, 22)
        Me.mnuFilePrint.Text = "&Print"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(152, 22)
        Me.mnuFileExit.Text = "E&xit"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.txtTotalOrder)
        Me.GroupBox4.Controls.Add(Me.txtTaxAmount)
        Me.GroupBox4.Controls.Add(Me.txtTaxRate)
        Me.GroupBox4.Controls.Add(Me.txtTotalLabor)
        Me.GroupBox4.Controls.Add(Me.txtTotalParts)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Location = New System.Drawing.Point(551, 358)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(200, 274)
        Me.GroupBox4.TabIndex = 25
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Order Summary"
        '
        'txtTotalOrder
        '
        Me.txtTotalOrder.Location = New System.Drawing.Point(21, 228)
        Me.txtTotalOrder.Name = "txtTotalOrder"
        Me.txtTotalOrder.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalOrder.TabIndex = 9
        Me.txtTotalOrder.Text = "0.00"
        '
        'txtTaxAmount
        '
        Me.txtTaxAmount.Location = New System.Drawing.Point(21, 179)
        Me.txtTaxAmount.Name = "txtTaxAmount"
        Me.txtTaxAmount.Size = New System.Drawing.Size(100, 20)
        Me.txtTaxAmount.TabIndex = 8
        Me.txtTaxAmount.Text = "0.00"
        '
        'txtTaxRate
        '
        Me.txtTaxRate.Location = New System.Drawing.Point(21, 125)
        Me.txtTaxRate.Name = "txtTaxRate"
        Me.txtTaxRate.Size = New System.Drawing.Size(100, 20)
        Me.txtTaxRate.TabIndex = 7
        Me.txtTaxRate.Text = "8.25"
        '
        'txtTotalLabor
        '
        Me.txtTotalLabor.Location = New System.Drawing.Point(21, 86)
        Me.txtTotalLabor.Name = "txtTotalLabor"
        Me.txtTotalLabor.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalLabor.TabIndex = 6
        Me.txtTotalLabor.Text = "0.00"
        '
        'txtTotalParts
        '
        Me.txtTotalParts.Location = New System.Drawing.Point(21, 36)
        Me.txtTotalParts.Name = "txtTotalParts"
        Me.txtTotalParts.Size = New System.Drawing.Size(100, 20)
        Me.txtTotalParts.TabIndex = 5
        Me.txtTotalParts.Text = "0.00"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(6, 205)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(60, 13)
        Me.Label18.TabIndex = 4
        Me.Label18.Text = "Total Order"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(4, 162)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(144, 13)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "Tax Amount (We really keep)"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(6, 109)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(51, 13)
        Me.Label16.TabIndex = 2
        Me.Label16.Text = "Tax Rate"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(9, 63)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(61, 13)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Total Labor"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(9, 20)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(58, 13)
        Me.Label14.TabIndex = 0
        Me.Label14.Text = "Total Parts"
        '
        'dlgPrint
        '
        Me.dlgPrint.Document = Me.docPrint
        Me.dlgPrint.PrintToFile = True
        Me.dlgPrint.UseEXDialog = True
        '
        'btnShowFile
        '
        Me.btnShowFile.Location = New System.Drawing.Point(583, 642)
        Me.btnShowFile.Name = "btnShowFile"
        Me.btnShowFile.Size = New System.Drawing.Size(88, 37)
        Me.btnShowFile.TabIndex = 26
        Me.btnShowFile.Text = "Show File"
        Me.btnShowFile.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(764, 693)
        Me.Controls.Add(Me.btnShowFile)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Vehicle Repair"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtCustomerName As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtCarYear As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtMake As System.Windows.Forms.TextBox
    Friend WithEvents txtModel As System.Windows.Forms.TextBox
    Friend WithEvents City As System.Windows.Forms.Label
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtState As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtZIPCode As System.Windows.Forms.TextBox
    Friend WithEvents txtProblem As System.Windows.Forms.RichTextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtSubTotal3 As System.Windows.Forms.TextBox
    Friend WithEvents txtQuantity3 As System.Windows.Forms.TextBox
    Friend WithEvents txtUnitPrice3 As System.Windows.Forms.TextBox
    Friend WithEvents txtPartName3 As System.Windows.Forms.TextBox
    Friend WithEvents txtSubTotal2 As System.Windows.Forms.TextBox
    Friend WithEvents txtQuantity2 As System.Windows.Forms.TextBox
    Friend WithEvents txtUnitPrice2 As System.Windows.Forms.TextBox
    Friend WithEvents txtPartName2 As System.Windows.Forms.TextBox
    Friend WithEvents txtSubTotal1 As System.Windows.Forms.TextBox
    Friend WithEvents txtQuantity1 As System.Windows.Forms.TextBox
    Friend WithEvents txtUnitPrice1 As System.Windows.Forms.TextBox
    Friend WithEvents txtPartName1 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtJobPrice2 As System.Windows.Forms.TextBox
    Friend WithEvents txtJobPrice3 As System.Windows.Forms.TextBox
    Friend WithEvents txtJobPerformed3 As System.Windows.Forms.TextBox
    Friend WithEvents txtJobPerformed2 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtJobPrice1 As System.Windows.Forms.TextBox
    Friend WithEvents txtJobPerformed1 As System.Windows.Forms.TextBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MnuFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileNew As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileOpen As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileSave As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFilePrint As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents txtTotalOrder As System.Windows.Forms.TextBox
    Friend WithEvents txtTaxAmount As System.Windows.Forms.TextBox
    Friend WithEvents txtTaxRate As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalLabor As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalParts As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtSubTotal5 As System.Windows.Forms.TextBox
    Friend WithEvents txtQuantity5 As System.Windows.Forms.TextBox
    Friend WithEvents txtUnitPrice5 As System.Windows.Forms.TextBox
    Friend WithEvents txtPartName5 As System.Windows.Forms.TextBox
    Friend WithEvents txtSubTotal4 As System.Windows.Forms.TextBox
    Friend WithEvents txtQuantity4 As System.Windows.Forms.TextBox
    Friend WithEvents txtUnitPrice4 As System.Windows.Forms.TextBox
    Friend WithEvents txtPartName4 As System.Windows.Forms.TextBox
    Friend WithEvents txtJobPrice5 As System.Windows.Forms.TextBox
    Friend WithEvents txtJobPrice4 As System.Windows.Forms.TextBox
    Friend WithEvents txtJobPerformed5 As System.Windows.Forms.TextBox
    Friend WithEvents txtJobPerformed4 As System.Windows.Forms.TextBox
    Friend WithEvents dlgPrint As System.Windows.Forms.PrintDialog
    Friend WithEvents docPrint As System.Drawing.Printing.PrintDocument
    Friend WithEvents btnShowFile As System.Windows.Forms.Button

End Class
