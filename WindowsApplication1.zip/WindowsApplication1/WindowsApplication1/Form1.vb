﻿Imports System.IO
Imports System.Text

Public Class Form1

    Private Sub Calculate()
        Dim UnitPricePart1 As Double, UnitPricePart2 As Double
        Dim UnitPricePart3 As Double, UnitPricePart4 As Double
        Dim UnitPricePart5 As Double
        Dim SubTotalPart1 As Double, SubTotalPart2 As Double
        Dim SubTotalPart3 As Double, SubTotalPart4 As Double
        Dim SubTotalPart5 As Double, TotalParts As Double
        Dim QuantityPart1 As Integer, QuantityPart2 As Integer
        Dim QuantityPart3 As Integer, QuantityPart4 As Integer
        Dim QuantityPart5 As Integer
        Dim Job1Price As Double, Job2Price As Double
        Dim Job3Price As Double, Job4Price As Double
        Dim Job5Price As Double, TotalLabor As Double
        Dim TaxRate As Double, TaxAmount As Double
        Dim TotalOrder As Double

        ' Don't charge a part unless it is clearly identified
        If txtPartName1.Text = "" Then
            txtUnitPrice1.Text = "0.00"
            txtQuantity1.Text = "0"
            txtSubTotal1.Text = "0.00"
            UnitPricePart1 = 0.0
        Else
            Try
                UnitPricePart1 = CDbl(txtUnitPrice1.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Unit Price")
                txtUnitPrice1.Text = "0.00"
                txtUnitPrice1.Focus()
            End Try

            Try
                QuantityPart1 = CInt(txtQuantity1.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Quantity")
                txtQuantity1.Text = "0"
                txtQuantity1.Focus()
            End Try
        End If

        If txtPartName2.Text = "" Then
            txtUnitPrice2.Text = "0.00"
            txtQuantity2.Text = "0"
            txtSubTotal2.Text = "0.00"
            UnitPricePart2 = 0.0
        Else
            Try
                UnitPricePart2 = CDbl(txtUnitPrice2.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Unit Price")
                txtUnitPrice2.Text = "0.00"
                txtUnitPrice2.Focus()
            End Try

            Try
                QuantityPart2 = CInt(txtQuantity2.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Quantity")
                txtQuantity2.Text = "0"
                txtQuantity2.Focus()
            End Try
        End If

        If txtPartName3.Text = "" Then
            txtUnitPrice3.Text = "0.00"
            txtQuantity3.Text = "0"
            txtSubTotal3.Text = "0.00"
            UnitPricePart3 = 0.0
        Else
            Try
                UnitPricePart3 = CDbl(txtUnitPrice3.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Unit Price")
                txtUnitPrice3.Text = "0.00"
                txtUnitPrice3.Focus()
            End Try

            Try
                QuantityPart3 = CInt(txtQuantity3.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Quantity")
                txtQuantity3.Text = "0"
                txtQuantity3.Focus()
            End Try
        End If

        If txtPartName4.Text = "" Then
            txtUnitPrice4.Text = "0.00"
            txtQuantity4.Text = "0"
            txtSubTotal4.Text = "0.00"
            UnitPricePart4 = 0.0
        Else
            Try
                UnitPricePart4 = CDbl(txtUnitPrice4.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Unit Price")
                txtUnitPrice4.Text = "0.00"
                txtUnitPrice4.Focus()
            End Try

            Try
                QuantityPart4 = CInt(txtQuantity4.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Quantity")
                txtQuantity4.Text = "0"
                txtQuantity4.Focus()
            End Try
        End If

        If txtPartName5.Text = "" Then
            txtUnitPrice5.Text = "0.00"
            txtQuantity5.Text = "0"
            txtSubTotal5.Text = "0.00"
            UnitPricePart5 = 0.0
        Else
            Try
                UnitPricePart5 = CDbl(txtUnitPrice5.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Unit Price")
                txtUnitPrice5.Text = "0.00"
                txtUnitPrice5.Focus()
            End Try

            Try
                QuantityPart5 = CInt(txtQuantity5.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Quantity")
                txtQuantity5.Text = "0"
                txtQuantity5.Focus()
            End Try
        End If

        ' Don't bill the customer for a job that is not specified
        If txtJobPerformed1.Text = "" Then
            txtJobPrice1.Text = "0.00"
            Job1Price = 0.0
        Else
            Try
                Job1Price = CDbl(txtJobPrice1.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Job Price")
                txtJobPrice1.Text = "0.00"
                txtJobPrice1.Focus()
            End Try
        End If

        If txtJobPerformed2.Text = "" Then
            txtJobPrice2.Text = "0.00"
            Job2Price = 0.0
        Else
            Try
                Job2Price = CDbl(txtJobPrice2.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Job Price")
                txtJobPrice2.Text = "0.00"
                txtJobPrice2.Focus()
            End Try
        End If

        If txtJobPerformed3.Text = "" Then
            txtJobPrice3.Text = "0.00"
            Job3Price = 0.0
        Else
            Try
                Job3Price = CDbl(txtJobPrice3.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Job Price")
                txtJobPrice3.Text = "0.00"
                txtJobPrice3.Focus()
            End Try
        End If

        If txtJobPerformed4.Text = "" Then
            txtJobPrice4.Text = "0.00"
            Job4Price = 0.0
        Else
            Try
                Job4Price = CDbl(txtJobPrice4.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Job Price")
                txtJobPrice4.Text = "0.00"
                txtJobPrice4.Focus()
            End Try
        End If

        If txtJobPerformed5.Text = "" Then
            txtJobPrice5.Text = "0.00"
            Job5Price = 0.0
        Else
            Try
                Job5Price = CDbl(txtJobPrice5.Text)
            Catch Exc As FormatException
                MsgBox("Invalid Job Price")
                txtJobPrice5.Text = "0.00"
                txtJobPrice5.Focus()
            End Try
        End If

        SubTotalPart1 = UnitPricePart1 * QuantityPart1
        SubTotalPart2 = UnitPricePart2 * QuantityPart2
        SubTotalPart3 = UnitPricePart3 * QuantityPart3
        SubTotalPart4 = UnitPricePart4 * QuantityPart4
        SubTotalPart5 = UnitPricePart5 * QuantityPart5

        txtSubTotal1.Text = FormatNumber(SubTotalPart1)
        txtSubTotal2.Text = FormatNumber(SubTotalPart2)
        txtSubTotal3.Text = FormatNumber(SubTotalPart3)
        txtSubTotal4.Text = FormatNumber(SubTotalPart4)
        txtSubTotal5.Text = FormatNumber(SubTotalPart5)

        TotalParts = SubTotalPart1 + SubTotalPart2 + SubTotalPart3 + SubTotalPart4 + SubTotalPart5

        TotalLabor = Job1Price + Job2Price + Job3Price + Job4Price + Job5Price

        txtTotalLabor.Text = FormatNumber(TotalLabor)
        txtTotalParts.Text = FormatNumber(TotalParts)
        TaxRate = 8.25
        'CDbl(txtTaxRate.Text)
        Dim totalPartsAndLabor As Double
        totalPartsAndLabor = TotalParts + TotalLabor
        TaxAmount = totalPartsAndLabor * TaxRate / 100
        TotalOrder = totalPartsAndLabor + TaxAmount
        txtTaxAmount.Text = FormatNumber(TaxAmount)
        txtTotalOrder.Text = FormatNumber(TotalOrder)

        'Try
        'TaxRate = CDbl(txtTaxRate.Text)
        'Catch Exc As FormatException
        'MsgBox("Invalid Tax Rate")
        'txtTaxRate.Text = "8.25"
        'txtTaxRate.Focus()
        'End Try

        'Dim totalPartsAndLabor As Double = TotalParts + TotalLabor
        TaxAmount = totalPartsAndLabor * TaxRate / 100
        TotalOrder = totalPartsAndLabor + TaxAmount

        'txtTotalParts.Text = FormatNumber(TotalParts)
        'txtTotalLabor.Text = FormatNumber(TotalLabor)
        txtTaxAmount.Text = FormatNumber(TaxAmount)
        txtTotalOrder.Text = FormatNumber(TotalOrder)
    End Sub
    'End Class



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load




    End Sub

    Private Sub mnuFileNew_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuFileNew.Click
        txtCustomerName.Text = ""
        txtAddress.Text = ""
        txtCity.Text = ""
        txtState.Text = ""
        txtZIPCode.Text = ""
        txtMake.Text = ""
        txtModel.Text = ""
        txtCarYear.Text = ""
        txtProblem.Text = ""

        txtPartName1.Text = ""
        txtUnitPrice1.Text = "0.00"
        txtQuantity1.Text = "0"
        txtSubTotal1.Text = "0.00"
        txtPartName2.Text = ""
        txtUnitPrice2.Text = "0.00"
        txtQuantity2.Text = "0"
        txtSubTotal2.Text = "0.00"
        txtPartName3.Text = ""
        txtUnitPrice3.Text = "0.00"
        txtQuantity3.Text = "0"
        txtSubTotal3.Text = "0.00"
        txtPartName4.Text = ""
        txtUnitPrice4.Text = "0.00"
        txtQuantity4.Text = "0"
        txtSubTotal4.Text = "0.00"
        txtPartName5.Text = ""
        txtUnitPrice5.Text = "0.00"
        txtQuantity5.Text = "0"
        txtSubTotal5.Text = "0.00"

        txtJobPerformed1.Text = ""
        txtJobPrice1.Text = "0.00"
        txtJobPerformed2.Text = ""
        txtJobPrice2.Text = "0.00"
        txtJobPerformed3.Text = ""
        txtJobPrice3.Text = "0.00"
        txtJobPerformed4.Text = ""
        txtJobPrice4.Text = "0.00"
        txtJobPerformed5.Text = ""
        txtJobPrice5.Text = "0.00"

        txtTotalParts.Text = "0.00"
        txtTotalLabor.Text = "0.00"
        txtTaxRate.Text = "7.75"
        txtTaxAmount.Text = "0.00"
        txtTotalOrder.Text = "0.00"

        txtCustomerName.Focus()
    End Sub


    Private Sub ControlsLeave(ByVal sender As Object, _
                              ByVal e As EventArgs) _
                              Handles txtUnitPrice1.Leave, _
                                      txtUnitPrice2.Leave, _
                                      txtUnitPrice3.Leave, _
                                      txtUnitPrice4.Leave, _
                                      txtUnitPrice5.Leave, _
                                      txtQuantity1.Leave, _
                                      txtQuantity2.Leave, _
                                      txtQuantity3.Leave, _
                                      txtQuantity4.Leave, _
                                      txtQuantity5.Leave, _
                                      txtJobPrice1.Leave, _
                                      txtJobPrice2.Leave, _
                                      txtJobPrice3.Leave, _
                                      txtJobPrice4.Leave, _
                                      txtJobPrice5.Leave, _
                                      txtTaxRate.Leave
        Calculate()
    End Sub

    Private Sub mnuFileExit_Click(ByVal sender As Object, _
                                  ByVal e As System.EventArgs) _
                                  Handles mnuFileExit.Click
        End
    End Sub



    Private Sub mnuFileSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles mnuFileSave.Click
        Dim iFilename As Integer
        Dim Filename As String
        Dim FolderName As String = "C:\JJacks"
        Dim Folder As DirectoryInfo = Directory.CreateDirectory(FolderName)
        Dim ListOfFiles() As FileInfo = Folder.GetFiles("*.txt")
        If ListOfFiles.Length = 0 Then
            iFilename = 1000
        Else
            Dim fleLast As FileInfo = ListOfFiles(ListOfFiles.Length - 1)
            Dim fwe As String = Path.GetFileNameWithoutExtension(fleLast.FullName)
            iFilename = CInt(fwe)
        End If

        Filename = FolderName + CStr(iFilename + 1) & ".txt"



    End Sub

   
    Private Sub btnShowFile_Click(sender As Object, e As EventArgs) Handles btnShowFile.Click
        System.Diagnostics.Process.Start("C:\JJacks\Cust.csv")
    End Sub
End Class
